package com.ttl.springboot2.SpringBootFullStackApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFullStackApplicationTests {

	@Test
	void contextLoads() {
	}

}
